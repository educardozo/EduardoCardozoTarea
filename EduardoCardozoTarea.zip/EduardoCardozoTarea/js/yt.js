$(function(){
	$('.selector a').click(function(){
		var ruta_img=$(this).attr('rel');
		$('#imagen').hide();		
		$('#imagen').fadeIn(800);
		$('#imagen img').attr('src', ruta_img);
		return false;
	})
})